# pandas-linear-regression
A library that adds linear regression functionality to pandas
